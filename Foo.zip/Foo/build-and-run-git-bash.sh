#

dotnet --version
dotnet restore
dotnet build
dotnet run
